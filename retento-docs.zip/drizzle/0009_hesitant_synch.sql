ALTER TABLE `initial_test_questions` ADD `feedbackForChoice1` text;--> statement-breakpoint
ALTER TABLE `initial_test_questions` ADD `feedbackForChoice2` text;--> statement-breakpoint
ALTER TABLE `initial_test_questions` ADD `feedbackForChoice3` text;--> statement-breakpoint
ALTER TABLE `initial_test_questions` ADD `feedbackForChoice4` text;